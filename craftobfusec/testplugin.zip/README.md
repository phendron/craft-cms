# Test Plugin plugin for Craft CMS 3.x

This is a Test Plugin

![Screenshot](resources/img/plugin-logo.png)

## Requirements

This plugin requires Craft CMS 3.0.0-beta.23 or later.

## Installation

To install the plugin, follow these instructions.

1. Open your terminal and go to your Craft project:

        cd /path/to/project

2. Then tell Composer to load the plugin:

        composer require /test-plugin

3. In the Control Panel, go to Settings → Plugins and click the “Install” button for Test Plugin.

## Test Plugin Overview

-Insert text here-

## Configuring Test Plugin

-Insert text here-

## Using Test Plugin

-Insert text here-

## Test Plugin Roadmap

Some things to do, and ideas for potential features:

* Release it

Brought to you by [Me](Me@me.me)
