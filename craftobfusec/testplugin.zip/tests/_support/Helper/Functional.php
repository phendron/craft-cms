<?php
/**
 * Test Plugin plugin for Craft CMS 3.x
 *
 * This is a Test Plugin
 *
 * @link      Me@me.me
 * @copyright Copyright (c) 2021 Me
 */

namespace Helper;

use Codeception\Module;

/**
 * Class Functional
 *
 * Here you can define custom actions.
 * All public methods declared in helper class will be available in $I
 */
class Functional extends Module
{

}
